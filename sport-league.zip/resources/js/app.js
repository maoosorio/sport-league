import '../sass/tabler.scss';
import './bootstrap';
import './tabler-init';
