
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('name')); ?></label>
    <div>
        <?php echo e(Form::text('name', $league->name, ['class' => 'form-control' .
        ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

        <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">league <b>name</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('id_user')); ?></label>
    <div>
        <?php echo e(Form::text('id_user', $league->id_user, ['class' => 'form-control' .
        ($errors->has('id_user') ? ' is-invalid' : ''), 'placeholder' => 'Id User'])); ?>

        <?php echo $errors->first('id_user', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">league <b>id_user</b> instruction.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label">   <?php echo e(Form::label('status')); ?></label>
    <div>
        <?php echo e(Form::text('status', $league->status, ['class' => 'form-control' .
        ($errors->has('status') ? ' is-invalid' : ''), 'placeholder' => 'Status'])); ?>

        <?php echo $errors->first('status', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">league <b>status</b> instruction.</small>
    </div>
</div>

    <div class="form-footer">
        <div class="text-end">
            <div class="d-flex">
                <a href="#" class="btn btn-danger">Cancel</a>
                <button type="submit" class="btn btn-primary ms-auto ajax-submit">Submit</button>
            </div>
        </div>
    </div>
<?php /**PATH C:\laragon\www\tablarcurso\resources\views/league/form.blade.php ENDPATH**/ ?>