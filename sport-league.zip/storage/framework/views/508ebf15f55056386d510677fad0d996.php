<div class="form-group mb-3">
    <label class="form-label"> <?php echo e(Form::label('Nombre')); ?></label>
    <div>
        <?php echo e(Form::text('name', $league->name, [
            'class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : ''),
            'placeholder' => 'Nombre',
        ])); ?>

        <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        <small class="form-hint">liga <b>nombre</b> requerido.</small>
    </div>
</div>
<div class="form-group mb-3">
    <label class="form-label"> <?php echo e(Form::label('Administrador')); ?></label>
    <div>
        <?php echo $errors->first('id_admin', '<div class="invalid-feedback">:message</div>'); ?>

        <select name="id_admin" id="id_admin" class="form-control select2bs4 <?php $__errorArgs = ['id_admin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($admin->id); ?>" <?php echo e(old('id_admin') == $admin->id ? 'selected=selected' : ''); ?>>
                    <?php echo e($admin->name); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <small class="form-hint">liga <b>administrador</b> requerido.</small>
    </div>
</div>

<div class="form-footer">
    <div class="text-end">
        <div class="d-flex">
            <a href="<?php echo e(route('leagues.index')); ?>" class="btn btn-danger">Cancelar</a>
            <button type="submit" class="btn btn-primary ms-auto ajax-submit">Guardar</button>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\sport-league\resources\views/league/form.blade.php ENDPATH**/ ?>