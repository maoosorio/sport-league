<a class="dropdown-item" href="<?php echo e($item['href']??''); ?>">
    <?php if(isset($item['icon'])): ?>
        <span class="nav-link-icon d-md-none d-lg-inline-block">
                        <!-- Download SVG icon from http://tabler-icons.io/i/package -->
              <i class="<?php echo e($item['icon'] ?? ''); ?> <?php echo e(isset($item['icon_color']) ? 'text-' . $item['icon_color'] : ''); ?>"></i>
        </span>
    <?php endif; ?>
    <?php echo e($item['text']??''); ?>

</a>
<?php /**PATH C:\laragon\www\tablarcurso\resources\views/vendor/tablar/partials/navbar/single-item.blade.php ENDPATH**/ ?>