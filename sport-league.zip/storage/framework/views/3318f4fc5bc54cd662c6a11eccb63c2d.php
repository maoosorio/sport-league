<a href="#">
    <img src="<?php echo e(asset(config('tablar.auth_logo.img.path','assets/tablar-logo.png'))); ?>" width="80" height="100"
         alt="<?php echo e(asset(config('tablar.title','Sport League'))); ?>"
         class="navbar-brand">
</a>
<?php /**PATH C:\laragon\www\tablarcurso\resources\views/vendor/tablar/partials/common/logo.blade.php ENDPATH**/ ?>