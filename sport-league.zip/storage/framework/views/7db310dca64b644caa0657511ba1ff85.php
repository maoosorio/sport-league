<?php
    $layoutData['cssClasses'] =  'navbar navbar-vertical navbar-expand-lg';
?>
<?php $__env->startSection('body'); ?>
    <body>
    <div class="page">
        <!-- Sidebar -->
        <?php echo $__env->make('tablar::partials.navbar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">
            <!-- Page Content -->
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('tablar::partials.footer.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    </body>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\laragon\www\sport-league\resources\views/vendor/tablar/layouts/vertical.blade.php ENDPATH**/ ?>