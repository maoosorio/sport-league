<?php
    $stickyTopClass = config('tablar.sticky_top_nav_bar') ? 'sticky-top' : '';
    $layoutData['cssClasses'] = 'navbar navbar-expand-md ' . $stickyTopClass . ' d-print-none';
?>
<?php $__env->startSection('body'); ?>
    <body>
    <div class="page">
        <!-- Top Navbar -->
        <?php echo $__env->make('tablar::partials.navbar.condensed-top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">
            <!-- Page Content -->
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('tablar::partials.footer.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    </body>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\laragon\www\tablarcurso\resources\views/vendor/tablar/layouts/condensed.blade.php ENDPATH**/ ?>