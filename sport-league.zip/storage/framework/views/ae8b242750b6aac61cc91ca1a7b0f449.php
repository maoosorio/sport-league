<header class="<?php echo e($layoutData['cssClasses'] ?? 'navbar navbar-expand-md navbar-overlap d-print-none'); ?>" data-bs-theme="dark">
    <div class="container-xl">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu"
                aria-controls="navbar-menu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <h1 class="navbar-brand navbar-brand-autodark d-none-navbar-horizontal pe-0 pe-md-3">
            <?php echo $__env->make('tablar::partials.common.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </h1>

        <div class="navbar-nav flex-row order-md-last">

            <div class="nav-item d-none d-md-flex me-3">
                <div class="btn-list">
                    <?php echo $__env->make('tablar::partials.header.header-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

            <div class="d-none d-md-flex">
                <?php echo $__env->make('tablar::partials.header.theme-mode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('tablar::partials.header.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <?php echo $__env->make('tablar::partials.header.top-right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="collapse navbar-collapse" id="navbar-menu">
            <div class="d-flex flex-column flex-md-row flex-fill align-items-stretch align-items-md-center">
                <ul class="navbar-nav">
                    <?php echo $__env->renderEach('tablar::partials.navbar.dropdown-item', $tablar->menu('sidebar'), 'item'); ?>
                </ul>
            </div>
        </div>
    </div>
</header>
<?php /**PATH C:\laragon\www\tablarcurso\resources\views/vendor/tablar/partials/navbar/overlap-topbar.blade.php ENDPATH**/ ?>